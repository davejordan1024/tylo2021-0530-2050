void brwsr_cb(Fl_Widget *brwsr) {

   cout << "brwsr callback" << endl;
   Brwsr *b = (Brwsr*) brwsr;
   game_s *gm = (game_s*) b->data(b->value());
   string msgstr;

   if(b->value() != 0 && gm != cur.game) {         // 0 happens when click occurs in brwsr but not on item
      unload_game(true);                           // write to game storage whether or not there has been any change
      load_game(gm);
      ((Msg *) ((App *) b->parent())->msg)->setmsg1(); }
   return;
}
void load_game(game_s *gm) {                       // copy the rack & board from game struct (gm->) to UI labels (tbl->)

   cout << "load " << gm << ' ' << gm->opp << ' ' << gm->starttm << endl;

   Tbl      *tbl        = gm->tbl;                 // part 1: figure out totals for oppcnt, bagcnt, vwl count, cons count, total remaining tile count,
   Bagcell  **rem       = tbl->rem,                // and for each ltr, remaining count
            **gvn       = tbl->gvn;
   Brdcell  ***tblbrd   = tbl->brd;                // NB tbl->brd is the onscreen board; gm->brd is the storage location while game not in use
   alpha_s  *alpha      = tbl->alpha,
            *match;
   int      alphan      = tbl->alphan,
            brdn        = tbl->brdn,
            brdnsq      = brdn * brdn,
            j, k, sign, ccnt, vcnt, tcnt;
   static const int
            nclr        = getiopt("bag_nega"),
            zclr        = getiopt("bag_zero"),
            pclr        = getiopt("bag_posi");
   char     *gmbrd      = gm->brd,                 // see NB above
            ltr;

   for(j = 0; j < alphan; j++)                     // init "remaining" bag column with "given" values. source: tbl::addobjects,
      rem[j]->copy_label(&(gvn[j]->label()[1]));   // all are invariant per tbl instance. offset 1 b/c "given" label starts with a slash

   ccnt = tbl->alphacn;                            // grab vwl/cons/tile counts from board instance. also invariant. from read_tmplts().
   vcnt = tbl->alphavn;
   tcnt = tbl->alphatn;

   for(j = 0; j < brdnsq; j++) {                                  // decrement cons/vwl/tile/individual counts using letters from game struct
      if(match = srch_keytab(alpha, alphan, gmbrd[j])) {
         switch(match->isvwl) {
            case '0':   ccnt--;           break;
            case '1':   vcnt--;           break;
            case '2':   ccnt--; vcnt--;   break;
         }
         rem[match->bagrow]->copy_label(                          // remaining quantities per letter are not stored anywhere; there is no
            STS(atoi(rem[match->bagrow]->label()) - 1).c_str()    // alpha[anything]->rem. so i just keep converting the labels back and forth
         );
         tcnt--;
      }
   }
   for(j = 0; j < tbl->rckn; j++) {                               // continue decrementing using rack
      if(match = srch_keytab(alpha, alphan, gm->rck[j])) {     // rack is small so dont bother with dereferencing tbl->* vars in advance
         switch(match->isvwl) {
            case '0':   ccnt--;           break;
            case '1':   vcnt--;           break;
            case '2':   ccnt--; vcnt--;   break;
         }
         rem[match->bagrow]->copy_label(
            STS(atoi(rem[match->bagrow]->label()) - 1).c_str()
         );
         tcnt--;
      }

   }
   tbl->cnscnt->copy_label(STS(ccnt).c_str());              // assign lbls for cons, vwl, tile
   tbl->vwlcnt->copy_label(STS(vcnt).c_str());
   tbl->tilecnt->copy_label(STS(tcnt).c_str());

   if(tcnt >= tbl->rckn) {
      tbl->oppcnt->text(gm->opp, tbl->rckn);                // assign lbl and count for opponent
      tbl->bagcnt->value(tcnt - tbl->rckn);                 // assign bag count
   }
   else {
      tbl->oppcnt->text(gm->opp, tcnt);
      tbl->bagcnt->value(0);
   }
   for(j = 0; j < alphan; j++) {                            // assign colors to bag based on remaining quantity
      sign = atoi(tbl->rem[j]->label());
      for(Bagcell *obj : { tbl->vis[j], tbl->pv[j], tbl->rem[j], tbl->gvn[j] }) {
         if       (sign == 0) obj->labelcolor(zclr);
         else if  (sign >  0) obj->labelcolor(pclr);
         else                 obj->labelcolor(nclr);
      }
   }
   // part 2: load board, rack, notes, set cur.*, tbl->show() etc. ======================================================

   for(j = 0; j < brdn; j++)                                      // load board
      for(k = 0; k < brdn; k++) {
         ltr = gmbrd[j * brdn + k];

         if(match = srch_keytab(alpha, alphan, ltr)) {
            tblbrd[j][k]->kystrk = ltr;
            tblbrd[j][k]->copy_label(match->vis);
         }
         else {
            tblbrd[j][k]->kystrk = FLLRCHR;
            tblbrd[j][k]->copy_label(FLLRLBL);
         }
      }
   for(j = 0; j < tbl->rckn; j++)                                 // load rack
      if(match = srch_keytab(alpha, alphan, gm->rck[j])) {
         tbl->rck[j]->copy_label(match->vis);
         tbl->rck[j]->kystrk = match->kystrk;
      }
      else {
         tbl->rck[j]->kystrk = FLLRCHR;
         tbl->rck[j]->copy_label(FLLRLBL);
      }

   tbl->notes->buffer(gm->buffy);                                    // attach buffer
   cur.game = gm;
   cur.tbl = tbl;
   tbl->show();
}
void mk_fmtd_text(game_s *gm) {                                      // create formatted menu item text
   cc *cd = gm->stat == GSACTV ? ACTVCD : OVERCD;
   gm->fmtd = (string) cd + gm->opp + COLSEP + cd + gm->starttm;
}
void mk_tilestr(game_s *gm, cc *cmpnm, cc *src) {                    // create gm->brd and gm->rck; fill with letters from game file

   Tbl *tbl = gm->tbl;
   char *dest;
   int n, j, nerrs = 0;
   
   if (! strcmp(cmpnm, "board")) {                                   // ??? new char array decls do not reserve mem unless they are initted with the parens
      gm->brd = new nt char[n = gm->tbl->brdn * gm->tbl->brdn]();
      dest = gm->brd;
   }
   else if (! strcmp(cmpnm, "rack"))   {
      gm->rck = new nt char[n = gm->tbl->rckn]();
      dest = gm->rck;
   }
   else {
      cout << "internal error: invalid component name in mk_tilestr()" << endl;
      exit(EXIT_FAILURE);
   }
   if(! dest)
      EOOM(cmpnm);

   for(j = 0; j < n && src[j]; j++) {
      if(src[j] == FLLRCHR) {
         dest[j] = FLLRCHR;
         continue;
      }
      if(srch_keytab(tbl->alpha, tbl->alphan, src[j])) {
         dest[j] = src[j];
         continue;
      }
      cout << "invalid char " << (int) src[j] << " " << src[j] << endl;
      dest[j] = FLLRCHR;
      nerrs++;
   }
   while(j < n)
      dest[j++] = FLLRCHR;
   
   if(nerrs)
      fl_alert("While reading %s, game record %s %s, %s section,\n%d invalid character(s) were replaced with \'%c\'.",
         GAMEFL, gm->opp, gm->starttm.c_str(), cmpnm, nerrs, FLLRCHR
      );
}
void notesmod_cb(int, int nInserted, int nDeleted, int, const char*, void* v) {
   if ((nInserted || nDeleted))
      setmod((App *) v, true);
}
bool open_file(cc *fn, FILE* &fh, cc *acc) {

   struct stat s;
   stat(fn, &s);
   if(! S_ISREG(s.st_mode))      { fl_alert("%s%s is neither a regular file nor a link to one.", home, fn); return false; }
   if(! (fh = fopen(fn, acc)))   { fl_alert("Could not open %s", fn); return false; }
   return true;
}
void parse_arg0(char *arg) {  // separate the name of the exe from the dir it lives in, leaving / at end of dir

   ptrdiff_t at = strrchr(arg, strchr(arg, '/') ? '/' : '\\') - arg + 1;

   home = strndup(arg, at);      // home and self are declared at global scope
   self = strdup(arg + at);
   chdir(home);
   char *tmp = get_current_dir_name();
   cout << "cwd is " << tmp << endl;
   free(tmp);

   return;
}
bool read_games(App *app) {

   Tbl **tbls = app->tbls;
   vector<game_s*> &games = app->games;   // games is a reference to a vector of pointers
   Brwsr *brwsr = app->brwsr;

   int ntslen, j, linenum = 0;
   char *gl_line = nullptr, *tmp, *tok;
   size_t gl_n = 0;
   ssize_t nread;       // must be a signed type otherwise -1 becomes 2^64-1 and getline loops "forever"
   game_s *gm;
   FILE *fh = NULL;
   
   if(! open_file(GAMEFL, fh, "r")) {
      bool cont = true;
      while(cont) {
         switch(fl_choice(GAMEFL "not found. What do you want to do?", 0, "Exit the program", "Create a new file")) {
            case 0:  break;               /* disallow esc or closing window */
            case 1:  return false;        /* back to caller */
            case 2:  cont = false; break;
         }
      }
      if(! (fh = fopen(GAMEFL, "a")))
         EINIT("Could not create " GAMEFL);
   }
   while((nread = getline(&gl_line, &gl_n, fh)) > 0) {
   
      try {
         linenum++;

         if(strlen(gl_line) > GMMAX) {
            fl_alert("line %d of %s is > %lu characters and will be ignored", linenum, GAMEFL, GMMAX);
            continue;
         }
         if(gl_line[nread - 1] == '\n')
            gl_line[nread - 1] = '\0';       // kill newline

         if(! (gm = new nt game_s))          // cout << "read game #" << cur.ngames + 1;
            EOOM("game");

         switch(gl_line[0]) {                            // game status
            case GSACTV :  case GSOVER :  break;
            case '\0'                  :  EGAME("Early eol looking for game status");
                                          break;
            default:
               gl_line[0] = GSACTV;
               fl_alert("Changed invalid game status to active, %s line %d.", GAMEFL, linenum);
         }
         gm->stat = gl_line[0];                          // 1 == in progress, 0 == over

         tmp = &gl_line[1];                              // strsep is used throughout this func to detect blank fields. strsep moves tmp as it processes
         tok = strsep(&tmp, "|");
         if((! tmp) || tok[0] == '\0')
            EGAME("Parse error at template name");

         for(j = 0; j < cur.ntbls; j++)                  // check table names for matching name
            if(! strcmp(tbls[j]->name, tok)) {
               gm->tbl = tbls[j];                        // put ptr to table into game struct
               break;
            }
         if(j == cur.ntbls)
            EGAME("Template name unknown");
         tok = strsep(&tmp, "|");
         if((! tmp) || tok[0] == '\0')
            EGAME("Parse error at opponent name");
         if(! (gm->opp = strdup(tok)))
            EOOM("opponent name");

         tok = strsep(&tmp, "|");
         if((! tmp) || tok[0] == '\0')
            EGAME("Parse error at game start time");
         if(strlen(tok) >= TIMESZ)
            EGAME("Start time too long");

         gm->starttm.assign(tok);                        // "cplusplus.com: Copies the null-terminated character sequence (C-string) pointed by s."
         mk_fmtd_text(gm);                               // formatted game id for browser, store in gm->fmtd

         tok = strsep(&tmp, "|");                        // *endtime == nul for games in progress but the next field delimiter still has to be there
         if(! tmp)
            EGAME("Parse error at game end time");
         if(strlen(tok) >= TIMESZ)
            EGAME("End time too long");
         gm->endtm.assign(tok);                          // 0-length copy seems to be ok

         tok = strsep(&tmp, "|");
         if(! tmp)
            EGAME("Parse error at rack");
         mk_tilestr(gm, "rack", tok);

         tok = strsep(&tmp, "|");
         if(! tmp)
            EGAME("Parse error at board");
         mk_tilestr(gm, "board", tok);

         if(! (gm->buffy = new nt Fl_Text_Buffer))
            EOOM("text buffer");
         
         tok = strsep(&tmp, "|");
         if(! tmp)
            EGAME("Parse error at notes length");
         ntslen = atoi(tok);
         
         if(ntslen > NTSMAX || ntslen < 0)
            fl_alert("While reading %s, game %s %s:\nNotes will be dropped because their length is recorded as outside the range 0 - %d characters.",
               GAMEFL, gm->opp, gm->starttm.c_str(), NTSMAX
            );                               
         else {
            if(tmp)
               for(j = 0; j < ntslen && tmp[j]; j++)
                  if(tmp[j] == NTSNL) tmp[j] = '\n';           // xlate notes newline (\1) to real newline
            gm->buffy->text(tmp);
         }
         gm->buffy->add_modify_callback(notesmod_cb, (*tbls)->parent());

         games.push_back(gm);
         cur.ngames++;                                         // increment cur *before* using as brwsr data arg
         cur.nactv += (gm->stat == GSACTV);
         brwsr->add(gm->fmtd.c_str(), gm);                     // cout << ' ' << gm << ' ' << gm->opp << ' ' << gm->starttm << endl;
      }
      catch(cc *msg) {
         fl_alert("%s, %s line %d", msg, GAMEFL, linenum);     // strangely, linenum remains in scope in catch block
      }
   }                                                           // end getline() loop
   free(gl_line);
   fclose(fh);                                                 // fh has to be legit here
   cout << cur.ngames << " games read" << endl;
   return true;
}
bool read_tbl_info(vector <tblinfo_s> &ti) {

   char        *line = nullptr;
   size_t      bufsz = 0;
   ssize_t     nread;
   tblinfo_s   thistbl;
   int         ntbls = 0, linenum = 0;
   FILE        *fh;
   
   if(! open_file(TMPLTFL, fh, "r"))
      return false;

   while((nread = getline(&line, &bufsz, fh)) > 1) {     // returns -1 presumably at eof and -1 on read error

      linenum++;
      if(nread > TMPLTMAX) {
         fl_alert("Ignoring line longer than %lu characters, %s #%d.", TMPLTMAX, TMPLTFL, linenum);
         continue;
      }
      cout << "read info for table #" << ++ntbls;
      line[nread - 1] = '\0';                            // maybe test these tokens here instead waiting until table ctor?
      thistbl.name   = strtok(line, "|");
      thistbl.brdn   = atoi(strtok(NULL, "|"));
      thistbl.rckn   = atoi(strtok(NULL, "|"));
      thistbl.alphan = atoi(strtok(NULL, "|"));
      thistbl.misc   = strtok(NULL, "\0");
      ti.push_back(thistbl);
      cout << ": " << thistbl.name << endl;
   }
   free(line);
   fclose(fh);
   return true;
}
void setmod(App *app, bool ismod) {                                  // set cur.mod to true or false and change app title to reflect
   if(ismod)   app->label(((string) "* " + APPTTL + " *").c_str());
   else        app->label(APPTTL);
   cur.mod = ismod;
}
alpha_s* srch_keytab(alpha_s *alpha, int btm, int ltr) {

   int top = 0, mid;

   btm--;
   while(top <= btm) {

      mid = top + (btm - top) / 2;

      if       (alpha[mid].kystrk < ltr)  top = mid + 1;
      else if  (alpha[mid].kystrk > ltr)  btm = mid - 1;
      else     return &alpha[mid];
   }
   return NULL;
}
void unload_game(bool hide) {             // copy UI strings to game struct. game brwsr remains unaltered.

   cout << "unload " << cur.game->opp << ' ' << cur.game->starttm << endl;

   game_s *gm = cur.game;
   Tbl *tbl = gm->tbl;                    // or tbl = cur.tbl but this is safer
   int j, k;                              // copy board and rack

   for(j = 0; j < tbl->brdn;  j++)
      for(k = 0; k < tbl->brdn; k++)
         gm->brd[j * tbl->brdn + k] = tbl->brd[j][k]->kystrk;
   for(j = 0; j < tbl->rckn;  j++)
      gm->rck[j] = tbl->rck[j]->kystrk;
   // the text_editor is part of the table but the ->buffer and its ->text() are already part of the game struct and don't need to be written back 
   if(hide) tbl->hide();
   return;
}
void update_cnts(Tbl *tbl, alpha_s *inc, alpha_s *dec) {       // does not refer to any cells having user interaction

   int qt, change = 1, tot, clr, row;
   Bagcell *bagrem;

   static int pclr = getiopt("bag_posi");
   static int nclr = getiopt("bag_nega");
   static int zclr = getiopt("bag_zero");

   for(alpha_s *p : { inc, dec }) {
      if(p) {
         row = p->bagrow;
         bagrem = tbl->rem[row];
         tbl->rem[row]->copy_label(I2CS(qt = atoi(bagrem->label()) + change));

         if       (qt > 0) clr = pclr;
         else if  (qt < 0) clr = nclr;
         else              clr = zclr;

         for(Bagcell *c : { tbl->vis[row], tbl->pv[row], tbl->rem[row], tbl->gvn[row] }) {
            c->labelcolor(clr);
            c->redraw();         // rem[row] actually changed its label content and so redraws without being told to. so maybe it'll redraw twice.
         }
         switch(p->isvwl) {
            case '0':   tbl->cnscnt->copy_label(I2CS(atoi(tbl->cnscnt->label()) + change)); break;
            case '1':   tbl->vwlcnt->copy_label(I2CS(atoi(tbl->vwlcnt->label()) + change)); break;
            case '2':   tbl->vwlcnt->copy_label(I2CS(atoi(tbl->vwlcnt->label()) + change));
                        tbl->cnscnt->copy_label(I2CS(atoi(tbl->cnscnt->label()) + change)); break;
            // default: anything else is fatal in read_tmplts()
         }
         tot = atoi(tbl->tilecnt->label()) + change;

         tbl->tilecnt->copy_label(I2CS(tot));

         if(tot >= tbl->rckn)
            tbl->oppcnt->value(tbl->rckn);
         else
            tbl->oppcnt->incr(change);
         tbl->bagcnt->value(tot - tbl->oppcnt->value());
      }
      change = -1;
   }
}
